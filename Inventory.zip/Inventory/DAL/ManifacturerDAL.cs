﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using System.Configuration;
using System.Data;


namespace DAL
{
    public class ManifacturerDAL:IDisposable
    {
        public List<Manifacturer> manifacturer;
        SqlConnection conn;
        SqlCommand cmd;
        string ConnectionString;
        SqlDataReader sdr;


        public void GetConnection()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            conn = new SqlConnection(ConnectionString);
            conn.Open();
        }
        public void CloseConnection()
        {
            ConnectionString = null;
            cmd = null;
            conn.Close();
        }

        public List<Manifacturer> GetAllManifacturer()
        {

            try
            {
                GetConnection();
                cmd = new SqlCommand("GetAllManifacturer", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                sdr = cmd.ExecuteReader();
                manifacturer = new List<Manifacturer>();
                while (sdr.Read())
                {
                    Manifacturer m = new Manifacturer();
                    m.ManifacturerId = Convert.ToInt32(sdr["ManifacturerId"].ToString());
                    m.ManifacturerName = sdr["ManifacturerName"].ToString();
                    m.ManifacturerAddress = sdr["ManifacturerAddress"].ToString();
                    m.ManifacturerContact = sdr["ManifacturerContact"].ToString();
                    manifacturer.Add(m);
                }

            }
            catch (Exception e)
            {

            }
            finally
            {

                CloseConnection();
            }
            return manifacturer;
        }

        public void CreateManifacturer(Manifacturer manifacturer)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("CreateManifacturer", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ManifacturerName", manifacturer.ManifacturerName);
                cmd.Parameters.AddWithValue("@ManifacturerAddress", manifacturer.ManifacturerAddress);
                cmd.Parameters.AddWithValue("@ManifacturerContact", manifacturer.ManifacturerContact);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }

        }
        public void EditManifacturer(Manifacturer manifacturer)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("EditManifacturer", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ManifacturerId", manifacturer.ManifacturerId);
                cmd.Parameters.AddWithValue("@ManifacturerName", manifacturer.ManifacturerName);
                cmd.Parameters.AddWithValue("@ManifacturerAddress", manifacturer.ManifacturerAddress);
                cmd.Parameters.AddWithValue("@ManifacturerContact", manifacturer.ManifacturerContact);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }
        }
        public void DeleteManifacturer(int id)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("DeleteManifacturer", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("ManifacturerId", id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }
        }

        public void Dispose()
        { 
        
        }
    }
}

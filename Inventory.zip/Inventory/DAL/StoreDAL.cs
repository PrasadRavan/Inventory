﻿using Core;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class StoreDAL:IDisposable
    {
        public List<Store> store;
        SqlConnection conn;
        SqlCommand cmd;
        string ConnectionString;
        SqlDataReader sdr;


        public void GetConnection()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            conn = new SqlConnection(ConnectionString);
            conn.Open();
        }
        public void CloseConnection()
        {
            ConnectionString = null;
            cmd = null;
            conn.Close();
        }

        public List<Store> GetAllStore()
        {

            try
            {
                GetConnection();
                cmd = new SqlCommand("GetAllStore", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                sdr = cmd.ExecuteReader();
                store = new List<Store>();
                while (sdr.Read())
                {
                    Store m = new Store();
                    m.StoreId = Convert.ToInt32(sdr["StoreId"].ToString());
                    m.StoreName = sdr["StoreName"].ToString();
                    m.StoreAddress = sdr["StoreAddress"].ToString();
                    m.StoreContact = sdr["StoreContact"].ToString();
                    store.Add(m);
                }

            }
            catch (Exception e)
            {

            }
            finally
            {

                CloseConnection();
            }
            return store;
        }

        public void CreateStore(Store store)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("CreateStore", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StoreName", store.StoreName);
                cmd.Parameters.AddWithValue("@StoreAddress", store.StoreAddress);
                cmd.Parameters.AddWithValue("@StoreContact", store.StoreContact);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }

        }
        public void EditStore(Store store)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("EditStore", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StoreId", store.StoreId);
                cmd.Parameters.AddWithValue("@StoreName", store.StoreName);
                cmd.Parameters.AddWithValue("@StoreAddress", store.StoreAddress);
                cmd.Parameters.AddWithValue("@StoreContact", store.StoreContact);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }
        }
        public void DeleteStore(int id)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("DeleteStore", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("StoreId", id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }
        }
        public void Dispose()
        { 
        
        }
    }
}

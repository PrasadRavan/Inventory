﻿using Core;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DistributorDAL: IDisposable
    {
        public List<Distributor> distributor;
        SqlConnection conn;
        SqlCommand cmd;
        string ConnectionString;
        SqlDataReader sdr;


        public void GetConnection()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            conn = new SqlConnection(ConnectionString);
            conn.Open();
        }
        public void CloseConnection()
        {
            ConnectionString = null;
            cmd = null;
            conn.Close();
        }

        public List<Distributor> GetAllDistributor()
        {

            try
            {
                GetConnection();
                cmd = new SqlCommand("GetAllDistributor", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                sdr = cmd.ExecuteReader();
                distributor = new List<Distributor>();
                while (sdr.Read())
                {
                    Distributor m = new Distributor();
                    m.DistributorId = Convert.ToInt32(sdr["DistributorId"].ToString());
                    m.DistributorName = sdr["DistributorName"].ToString();
                    m.DistributorAddress = sdr["DistributorAddress"].ToString();
                    m.DistributorContact = sdr["DistributorContact"].ToString();
                    distributor.Add(m);
                }

            }
            catch (Exception e)
            {

            }
            finally
            {

                CloseConnection();
            }
            return distributor;
        }

        public void CreateDistributor(Distributor distributor)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("CreateDistributor", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DistributorName", distributor.DistributorName);
                cmd.Parameters.AddWithValue("@DistributorAddress", distributor.DistributorAddress);
                cmd.Parameters.AddWithValue("@DistributorContact", distributor.DistributorContact);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }

        }
        public void EditDistributor(Distributor distributor)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("EditDistributor", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DistributorId", distributor.DistributorId);
                cmd.Parameters.AddWithValue("@DistributorName", distributor.DistributorName);
                cmd.Parameters.AddWithValue("@DistributorAddress", distributor.DistributorAddress);
                cmd.Parameters.AddWithValue("@DistributorContact", distributor.DistributorContact);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }
        }
        public void DeleteDistributor(int id)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("DeleteDistributor", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("DistributorId", id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }
        }
        public void Dispose()
        { 
        
        }
    }
}

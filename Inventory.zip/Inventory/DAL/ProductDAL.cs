﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace DAL
{
    public class ProductDAL
    {
        public List<Product> product;
        SqlConnection conn;
        SqlCommand cmd;
        string ConnectionString;
        SqlDataReader sdr;


        public void GetConnection()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            conn= new SqlConnection (ConnectionString);
            conn.Open();
        }
        public void CloseConnection()
        { 
            ConnectionString=null;
            cmd = null;
            conn.Close();
        }

        public List<Product> GetAllProducts()
        {
            
            try
            {
                GetConnection();
                cmd = new SqlCommand("GetAllProducts", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                sdr = cmd.ExecuteReader();
                product = new List<Product>();
                while (sdr.Read())
                {
                    Product p = new Product();
                    p.ProductID = Convert.ToInt32(sdr["ProductId"]);
                    p.ProductName = sdr["ProductName"].ToString();
                    p.Price = Convert.ToDouble(sdr["Price"]);
                    p.Category=sdr["Category"].ToString();
                    p.Manifacturer = sdr["Manifacturer"].ToString();
                    product.Add(p);
                }
                
            }
            catch (Exception e)
            {

            }
            finally 
            {
                
                CloseConnection();
            }
            return product;
        }

        public void CreateProduct(Product product)
        {
            try
            {
                GetConnection();
                cmd = new SqlCommand("CreateProduct", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductName",product.ProductName);
                cmd.Parameters.AddWithValue("@Price",product.Price);
                cmd.Parameters.AddWithValue("@Category",product.Category);
                cmd.Parameters.AddWithValue("@Manifacturer",product.Manifacturer);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
            finally
            {
                CloseConnection();
            }

        }


    }
}

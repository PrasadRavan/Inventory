﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class Store
    {
        [Key]
        public Int32 StoreId { get; set; }
        [Required]
        public String StoreName { get; set; }
        [Required]
        public String StoreAddress { get; set; }
        [Required]
        public String StoreContact { get; set; }
        
    }
}

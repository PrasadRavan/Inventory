﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class Distributor
    {
        [Key]
        public Int32 DistributorId { get; set; }
        [Required]
        public String DistributorName { get; set;}
        [Required]
        public String DistributorAddress { get; set; }
        [Required]
        public String DistributorContact { get; set; }
    }
}

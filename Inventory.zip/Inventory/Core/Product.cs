﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Core
{
    public class Product
    {
        [Key]
        public Int32 ProductID { get; set; }
        [Required]
        public String ProductName { get; set; }
        [Required]
        public Double Price { get; set; }
        [Required]
        public String Category { get; set; }
        [Required]
        public String Manifacturer { get; set; }

        public List<String> Categorty{get;set;}
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class Manifacturer
    {
        [Key]
        public Int32 ManifacturerId { get; set; }
        [Required]
        public String ManifacturerName { get; set; }
        [Required]
        public String ManifacturerAddress { get; set; }
        [Required]
        public String ManifacturerContact { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using DAL;
namespace BAL
{
    public class ProductBAL
    {
        List<Product> product = new List<Product>();
        ProductDAL productDAL = new ProductDAL();

        public List<Product> GetAllProducts()
        {
            productDAL = new ProductDAL();
            product = productDAL.GetAllProducts();
            return product;
        }

        public void CreateProduct(Product product)
        {
            productDAL = new ProductDAL();
            productDAL.CreateProduct(product);
            
        }
    }
}

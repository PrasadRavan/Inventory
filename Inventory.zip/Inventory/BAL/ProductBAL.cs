﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using DAL;
namespace BAL
{
    public class ProductBAL:IDisposable
    {
        List<Product> productList = new List<Product>();
        ProductDAL productDAL = new ProductDAL();
        Product product;

        public List<Product> GetAllProducts()
        {
            try
            {
                productDAL = new ProductDAL();
                productList = new List<Product>();
                productList = productDAL.GetAllProducts();
            }
            catch (Exception e)
            {

            }
            return productList;
        }

        public void CreateProduct(Product product)
        {
            try
            {
                productDAL = new ProductDAL();
                productDAL.CreateProduct(product);
            }
            catch (Exception e)
            {

            }

        }

        public Product GetEdit(int ProductId)
        {
            try
            {
                product = new Product();
                productDAL = new ProductDAL();
                productList = new List<Product>();
                productList = productDAL.GetAllProducts();
                product = productList.Single(pro => pro.ProductID == ProductId);
            }
            catch (Exception e)
            {

            }
            return product;
        }

        public void EditProduct(Product product)
        {
            productDAL = new ProductDAL();
            productDAL.EditProduct(product);
        }

        public void DeleteProduct(int id)
        {
            productDAL = new ProductDAL();
            productDAL.DeleteProduct(id);
        }
        public void Dispose()
        { 
        
        }
    }
}

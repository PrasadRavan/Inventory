﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using DAL;

namespace BAL
{
    public class ManifacturerBAL
    {
        List<Manifacturer> manifacturer = new List<Manifacturer>();
        ManifacturerDAL manifacturerDAL = new ManifacturerDAL();

        public List<Manifacturer> GetAllManifacturer()
        {
            manifacturerDAL = new ManifacturerDAL();
            manifacturer = manifacturerDAL.GetAllManifacturer();
            return manifacturer;
        }

        public void CreateManifacturer(Manifacturer manifacturer)
        {
            manifacturerDAL = new ManifacturerDAL();
            manifacturerDAL.CreateManifacturer(manifacturer);

        }
    }
}

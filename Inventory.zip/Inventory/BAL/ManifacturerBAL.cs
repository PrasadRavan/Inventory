﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using DAL;

namespace BAL
{
    public class ManifacturerBAL:IDisposable
    {
        List<Manifacturer> manifacturerList = new List<Manifacturer>();
        ManifacturerDAL manifacturerDAL = new ManifacturerDAL();
        Manifacturer manifacturer = new Manifacturer();
        public List<Manifacturer> GetAllManifacturer()
        {
            manifacturerDAL = new ManifacturerDAL();
            manifacturerList = manifacturerDAL.GetAllManifacturer();
            return manifacturerList;
        }

        public void CreateManifacturer(Manifacturer manifacturer)
        {
            manifacturerDAL = new ManifacturerDAL();
            manifacturerDAL.CreateManifacturer(manifacturer);

        }
        public Manifacturer GetEdit(int ManifacturerId)
        {
            try
            {
                manifacturer = new Manifacturer();
                manifacturerDAL = new ManifacturerDAL();
                manifacturerList = new List<Manifacturer>();
                manifacturerList = manifacturerDAL.GetAllManifacturer();
                manifacturer = manifacturerList.Single(man => man.ManifacturerId == ManifacturerId);
            }
            catch (Exception e)
            {

            }
            return manifacturer;
        }

        public void EditManifacturer(Manifacturer manifacturer)
        {
            manifacturerDAL = new ManifacturerDAL();
            manifacturerDAL.EditManifacturer(manifacturer);
        }
        public void DeleteManifacturer(int id)
        {
            manifacturerDAL = new ManifacturerDAL();
            manifacturerDAL.DeleteManifacturer(id);
        }
        public void Dispose()
        { 
        
        }
    }
}

﻿using Core;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class DistributorBAL:IDisposable
    {
        List<Distributor> distributorList = new List<Distributor>();
        DistributorDAL distributorDAL = new DistributorDAL();
        Distributor distributor = new Distributor();

        public List<Distributor> GetAllDistributor()
        {
            distributorDAL = new DistributorDAL();
            distributorList = distributorDAL.GetAllDistributor();
            return distributorList;
        }

        public void CreateDistributor(Distributor distributor)
        {
            distributorDAL = new DistributorDAL();
            distributorDAL.CreateDistributor(distributor);

        }
        public Distributor GetEdit(int DistributorId)
        {
            try
            {
                distributor = new Distributor();
                distributorDAL = new DistributorDAL();
                distributorList = new List<Distributor>();
                distributorList = distributorDAL.GetAllDistributor();
                distributor = distributorList.Single(sto => sto.DistributorId == DistributorId);
            }
            catch (Exception e)
            {

            }
            return distributor;
        }

        public void EditDistributor(Distributor distributor)
        {
            distributorDAL = new DistributorDAL();
            distributorDAL.EditDistributor(distributor);
        }
        public void DeleteDistributor(int id)
        {
            distributorDAL = new DistributorDAL();
            distributorDAL.DeleteDistributor(id);
        }
        public void Dispose()
        { 
        
        }

    }
}

﻿using Core;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class StoreBAL
    {
        List<Store> store = new List<Store>();
        StoreDAL storeDAL = new StoreDAL();

        public List<Store> GetAllStore()
        {
            storeDAL = new StoreDAL();
            store = storeDAL.GetAllStore();
            return store;
        }

        public void CreateStore(Store store)
        {
            storeDAL = new StoreDAL();
            storeDAL.CreateStore(store);

        }
    }
}

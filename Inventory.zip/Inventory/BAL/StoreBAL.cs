﻿using Core;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class StoreBAL:IDisposable
    {
        List<Store> storeList = new List<Store>();
        StoreDAL storeDAL = new StoreDAL();
        Store store = new Store();

        public List<Store> GetAllStore()
        {
            storeDAL = new StoreDAL();
            storeList = storeDAL.GetAllStore();
            return storeList;
        }

        public void CreateStore(Store store)
        {
            storeDAL = new StoreDAL();
            storeDAL.CreateStore(store);

        }
        public Store GetEdit(int StoreId)
        {
            try
            {
                store = new Store();
                storeDAL = new StoreDAL();
                storeList = new List<Store>();
                storeList = storeDAL.GetAllStore();
                store = storeList.Single(sto => sto.StoreId == StoreId);
            }
            catch (Exception e)
            {

            }
            return store;
        }

        public void EditStore(Store store)
        {
            storeDAL = new StoreDAL();
            storeDAL.EditStore(store);
        }
        public void DeleteStore(int id)
        {
            storeDAL = new StoreDAL();
            storeDAL.DeleteStore(id);
        }
        public void Dispose()
        { 
        
        }
    }
}

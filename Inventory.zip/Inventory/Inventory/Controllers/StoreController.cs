﻿using BAL;
using Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Inventory.Controllers
{
    public class StoreController : Controller
    {
        List<Store> storeList = new List<Store>();
        StoreBAL storeBAL = new StoreBAL();
        Store store = new Store();
        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult GetStoreList()
        {
            storeBAL = new StoreBAL();
            storeList = storeBAL.GetAllStore();
            return View(storeList);
        }
        [Authorize]
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult Create(FormCollection formCollection)
        {
            store = new Store();
            store.StoreName = formCollection["StoreName"];
            store.StoreAddress = formCollection["StoreAddress"];
            store.StoreContact = formCollection["StoreContact"];
            storeBAL.CreateStore(store);
            return View();
        }
        [Authorize]
        [HttpGet]
        public ActionResult Edit(int id)
        {
            store = new Store();
            storeBAL = new StoreBAL();
            store = storeBAL.GetEdit(id);
            return View(store);
        }
        [Authorize]
        [HttpPost]
        public ActionResult Edit(FormCollection formCollection)
        {
            store = new Store();
            storeBAL = new StoreBAL();
            store.StoreId = Convert.ToInt32(formCollection["StoreId"].ToString());
            store.StoreName = formCollection["StoreName"];
            store.StoreAddress = formCollection["StoreAddress"];
            store.StoreContact = formCollection["StoreContact"];
            storeBAL.EditStore(store);
            return RedirectToAction("GetStoreList");
        }
        [Authorize]
        public ActionResult Details(int id)
        {
            store = new Store();
            storeBAL = new StoreBAL();
            store = storeBAL.GetEdit(id);
            return View(store);
        }
        [Authorize]
        [HttpGet]
        public ActionResult Delete(int id)
        {
            store = new Store();
            storeBAL = new StoreBAL();
            store = storeBAL.GetEdit(id);
            return View(store);
        }
        [Authorize]
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            storeBAL = new StoreBAL();
            storeBAL.DeleteStore(id);
            return RedirectToAction("GetStoreList");
        }
    }
}

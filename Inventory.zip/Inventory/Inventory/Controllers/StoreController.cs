﻿using BAL;
using Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Inventory.Controllers
{
    public class StoreController : Controller
    {
        List<Store> storeList = new List<Store>();
        StoreBAL storeBAL = new StoreBAL();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetStoreList()
        {
            storeBAL = new StoreBAL();
            storeList = storeBAL.GetAllStore();
            return View(storeList);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(FormCollection formCollection)
        {
            Store store = new Store();
            store.StoreName = formCollection["StoreName"];
            store.StoreAddress = formCollection["StoreAddress"];
            store.StoreContact = formCollection["StoreContact"];
            storeBAL.CreateStore(store);
            return View();
        }

    }
}

﻿using BAL;
using Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Inventory.Controllers
{
    public class DistributorController : Controller
    {
        List<Distributor> distributorList = new List<Distributor>();
        DistributorBAL distributorBAL = new DistributorBAL();
        Distributor distributor = new Distributor();
        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult GetDistributorList()
        {
            distributorBAL = new DistributorBAL();
            distributorList = distributorBAL.GetAllDistributor();
            return View(distributorList);
        }
        [Authorize]
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult Create(FormCollection formCollection)
        {
            distributor = new Distributor();
            distributor.DistributorName = formCollection["DistributorName"];
            distributor.DistributorAddress = formCollection["DistributorAddress"];
            distributor.DistributorContact = formCollection["DistributorContact"];
            distributorBAL.CreateDistributor(distributor);
            return View();
        }
        [Authorize]
        [HttpGet]
        public ActionResult Edit(int id)
        {
            distributor = new Distributor();
            distributorBAL = new DistributorBAL();
            distributor = distributorBAL.GetEdit(id);
            return View(distributor);
        }
        [Authorize]
        [HttpPost]
        public ActionResult Edit(FormCollection formCollection)
        {
            distributor = new Distributor();
            distributorBAL = new DistributorBAL();
            distributor.DistributorId = Convert.ToInt32(formCollection["DistributorId"].ToString());
            distributor.DistributorName = formCollection["DistributorName"];
            distributor.DistributorAddress = formCollection["DistributorAddress"];
            distributor.DistributorContact = formCollection["DistributorContact"];
            distributorBAL.EditDistributor(distributor);
            return RedirectToAction("GetDistributorList");
        }
        [Authorize]
        public ActionResult Details(int id)
        {
            distributor = new Distributor();
            distributorBAL = new DistributorBAL();
            distributor = distributorBAL.GetEdit(id);
            return View(distributor);
        }
        [Authorize]
        [HttpGet]
        public ActionResult Delete(int id)
        {
            distributor = new Distributor();
            distributorBAL = new DistributorBAL();
            distributor = distributorBAL.GetEdit(id);
            return View(distributor);
        }
        [Authorize]
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            distributorBAL = new DistributorBAL();
            distributorBAL.DeleteDistributor(id);
            return RedirectToAction("GetDistributorList");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Core;
using BAL;

namespace Inventory.Controllers
{
    public class ManifacturerController : Controller
    {
        List<Manifacturer> manifacturerList = new List<Manifacturer>();
        ManifacturerBAL manifacturerBAL = new ManifacturerBAL();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetManifacturerList()
        {
            manifacturerBAL = new ManifacturerBAL();
            manifacturerList = manifacturerBAL.GetAllManifacturer();
            return View(manifacturerList);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(FormCollection formCollection)
        {
            Manifacturer manifacturer = new Manifacturer();
            manifacturer.ManifacturerName = formCollection["ManifacturerName"];
            manifacturer.ManifacturerAddress = formCollection["ManifacturerAddress"];
            manifacturer.ManifacturerContact = formCollection["ManifacturerContact"];
            manifacturerBAL.CreateManifacturer(manifacturer);
            return View();
        }

    }
}

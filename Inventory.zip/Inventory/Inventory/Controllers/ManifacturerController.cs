﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Core;
using BAL;

namespace Inventory.Controllers
{
    public class ManifacturerController : Controller
    {
        List<Manifacturer> manifacturerList = new List<Manifacturer>();
        ManifacturerBAL manifacturerBAL = new ManifacturerBAL();
        Manifacturer manifacturer = new Manifacturer();
        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult GetManifacturerList()
        {
            manifacturerBAL = new ManifacturerBAL();
            manifacturerList = manifacturerBAL.GetAllManifacturer();
            return View(manifacturerList);
        }
        [Authorize]
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult Create(FormCollection formCollection)
        {
            manifacturer = new Manifacturer();
            manifacturer.ManifacturerName = formCollection["ManifacturerName"];
            manifacturer.ManifacturerAddress = formCollection["ManifacturerAddress"];
            manifacturer.ManifacturerContact = formCollection["ManifacturerContact"];
            manifacturerBAL.CreateManifacturer(manifacturer);
            return View();
        }
        [Authorize]
        [HttpGet]
        public ActionResult Edit(int id)
        {
            manifacturer = new Manifacturer();
            manifacturerBAL = new ManifacturerBAL();
            manifacturer = manifacturerBAL.GetEdit(id);
            return View(manifacturer);
        }
        [Authorize]
        [HttpPost]
        public ActionResult Edit(FormCollection formCollection)
        {
            manifacturer = new Manifacturer();
            manifacturerBAL = new ManifacturerBAL();
            manifacturer.ManifacturerId = Convert.ToInt32(formCollection["ManifacturerId"].ToString());
            manifacturer.ManifacturerName = formCollection["ManifacturerName"];
            manifacturer.ManifacturerAddress = formCollection["ManifacturerAddress"];
            manifacturer.ManifacturerContact = formCollection["ManifacturerContact"];
            manifacturerBAL.EditManifacturer(manifacturer);
            return RedirectToAction("GetManifacturerList");
        }
        [Authorize]
        public ActionResult Details(int id)
        {
            manifacturer = new Manifacturer();
            manifacturerBAL = new ManifacturerBAL();
            manifacturer = manifacturerBAL.GetEdit(id);
            return View(manifacturer);
        }
        [Authorize]
        [HttpGet]
        public ActionResult Delete(int id)
        {
            manifacturer = new Manifacturer();
            manifacturerBAL = new ManifacturerBAL();
            manifacturer = manifacturerBAL.GetEdit(id);
            return View(manifacturer);
        }
        [Authorize]
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            manifacturerBAL = new ManifacturerBAL();
            manifacturerBAL.DeleteManifacturer(id);
            return RedirectToAction("GetManifacturerList");
        }
    }
}

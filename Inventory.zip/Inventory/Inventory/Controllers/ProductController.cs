﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BAL;
using Core;

namespace Inventory.Controllers
{
    public class ProductController : Controller
    {
        //
        // GET: /Product/
        List<Product> productList = new List<Product>();
        ProductBAL productBAL = new ProductBAL();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetProductList()
        {
            productBAL = new ProductBAL();
            productList=productBAL.GetAllProducts();
            return View(productList);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(FormCollection formCollection)
        {
            Product product = new Product();
            productBAL = new ProductBAL();
            product.ProductName = formCollection["ProductName"];
            product.Category = formCollection["Category"];
            product.Manifacturer = formCollection["Manifacturer"];
            product.Price = Convert.ToInt32(formCollection["Price"]);
            productBAL.CreateProduct(product);
            return View();
        }
    }
}

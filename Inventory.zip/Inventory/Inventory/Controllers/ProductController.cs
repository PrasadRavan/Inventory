﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BAL;
using Core;

namespace Inventory.Controllers
{
    public class ProductController : Controller
    {
        //
        // GET: /Product/
        List<Product> productList = new List<Product>();
        ProductBAL productBAL = new ProductBAL();
        Product product = new Product();
        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult GetProductList()
        {
            productBAL = new ProductBAL();
            productList = new List<Product>();
            productList=productBAL.GetAllProducts();
            return View(productList);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(FormCollection formCollection)
        {
            product = new Product();
            productBAL = new ProductBAL();
            product.ProductName = formCollection["ProductName"];
            product.Category = formCollection["Category"];
            product.Manifacturer = formCollection["Manifacturer"];
            product.Price = Convert.ToDouble(formCollection["Price"]);
            productBAL.CreateProduct(product);
            return View();
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            product = new Product();
            productBAL = new ProductBAL();
            product = productBAL.GetEdit(id);
            return View(product);
        }
        [HttpPost]
        public ActionResult Edit(FormCollection formCollection)
        {
            product = new Product();
            productBAL = new ProductBAL();
            product.ProductID = Convert.ToInt32(formCollection["ProductID"].ToString());
            product.ProductName = formCollection["ProductName"];
            product.Category = formCollection["Category"];
            product.Manifacturer = formCollection["Manifacturer"];
            product.Price = Convert.ToDouble(formCollection["Price"]);
            productBAL.EditProduct(product);
            return RedirectToAction("GetProductList");
        }

        public ActionResult Details(int id)
        {
            product = new Product();
            productBAL = new ProductBAL();
            product = productBAL.GetEdit(id);
            return View(product);
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            product = new Product();
            productBAL = new ProductBAL();
            product = productBAL.GetEdit(id);
            return View(product);
        }
        [HttpPost,ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            product = new Product();
            productBAL = new ProductBAL();
            productBAL.DeleteProduct(id);
            return RedirectToAction("GetProductList");
        }
    }
}
